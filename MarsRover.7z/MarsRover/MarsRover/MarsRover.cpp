// MarsRover.cpp : Defines the entry point for the console application.
//

#include <stdlib.h>

#include "MarsRover.h"

namespace MarsRover{

	Plateau::Plateau( int len, int width )
		: mLeftButtom( 0, 0 ), mRightTop( len, width ){
	
	}

	bool Plateau::Contains( const Position& aPos )const{

		bool ret = false;
		int x = aPos.GetX();
		int y = aPos.GetY();

		if ( x >= mLeftButtom.GetX() && x <= mRightTop.GetX() ){
		
			if ( y >= mLeftButtom.GetY() && y <= mRightTop.GetY() ) ret = true;
		}
		return ret;
	}

	//Action related

	//NorthAction

	RoverAction* NorthAction::SpinLeft(){
	
		return CreateActionSington<WestAction>();
	}

	RoverAction* NorthAction::SpinRight(){

		return CreateActionSington<EastAction>();
	}

	Position NorthAction::TryToMove( const Position& aPos ){
	
		return Position( aPos.GetX(), aPos.GetY() + 1 );
	}

	const char* NorthAction::GetState(){
	
		return "N";
	}

	//EastAction

	RoverAction* EastAction::SpinLeft(){
	
		return CreateActionSington<NorthAction>();
	}

	RoverAction* EastAction::SpinRight(){

		return CreateActionSington<SouthAction>();
	}

	Position EastAction::TryToMove( const Position& aPos ){
	
		return Position( aPos.GetX() + 1, aPos.GetY() );
	}

	const char* EastAction::GetState(){
	
		return "E";
	}

	//South

	
	RoverAction* SouthAction::SpinLeft(){
	
		return CreateActionSington<EastAction>();
	}

	RoverAction* SouthAction::SpinRight(){

		return CreateActionSington<WestAction>();
	}

	Position SouthAction::TryToMove( const Position& aPos ){
	
		return Position( aPos.GetX(), aPos.GetY() - 1 );
	}

	const char* SouthAction::GetState(){
	
		return "S";
	}

	//West

	RoverAction* WestAction::SpinLeft(){
	
		return CreateActionSington<SouthAction>();
	}

	RoverAction* WestAction::SpinRight(){

		return CreateActionSington<NorthAction>();
	}

	Position WestAction::TryToMove( const Position& aPos ){
	
		return Position( aPos.GetX() - 1, aPos.GetY() );
	}

	const char* WestAction::GetState(){
	
		return "W";
	}


	//Command related

	void SpinLeft::Execute( Position& aPos, RoverAction*& apAction, const Plateau& arPlateau ){

		RoverAction* newAction = apAction->SpinLeft();
		apAction = newAction;
	}

	void SpinRight::Execute( Position& aPos, RoverAction*& apAction, const Plateau& arPlateau ){

		RoverAction* newAction = apAction->SpinRight();
		apAction = newAction;
	}

	void Move::Execute( Position& aPos, RoverAction*& apAction, const Plateau& arPlateau ){

		Position newPos = apAction->TryToMove( aPos );

		if ( arPlateau.Contains( newPos) ){

			aPos = newPos;
		}
	}

	// Rover implementation

	Rover::Rover( const Plateau& aPlat,const Position& aPos, RoverAction* apAction) 
		:mrPlateau( aPlat ),mPos( aPos),mpAction( apAction ){
	
	}

	bool Rover::AcceptCommand( Command& aCmd ){
	
		aCmd.Execute( mPos, mpAction, mrPlateau );
		return true;
	}

	bool Rover::GetState( string& aReport ){

		char res[64];

		_itoa_s( mPos.GetX(), res, 10 );
		aReport += res;
		aReport += " ";
		_itoa_s( mPos.GetY(), res, 10 );
		aReport += res;
		aReport += " ";

		aReport += mpAction->GetState();

		return true;
	}

}
