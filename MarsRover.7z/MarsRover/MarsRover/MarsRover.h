#ifndef MARS_ROVER
#define MARS_ROVER

#include <string>

namespace MarsRover{

	using std::string;

	class Position{
	
	public:
		Position( int x, int y ) :mX( x ), mY( y ){}

		int SetX( int aX ){ mX = aX ;}
		int GetX( ) const { return mX ;}
		int SetY( int aY ){ mY = aY ;}
		int GetY() const { return mY;}

	private:
		int mX;
		int mY;

	};

	class Plateau{

	public:
		Plateau( int, int );
		bool Contains( const Position& ) const;
	
		
	private:
		Position mLeftButtom;
		Position mRightTop;
	
	};

	class RoverAction{

	public:
		virtual ~RoverAction(){};

		virtual RoverAction* SpinLeft() = 0;
		virtual RoverAction* SpinRight() = 0;
		virtual Position TryToMove( const Position& ) = 0;
		virtual const char* GetState() = 0;
	};

	class NorthAction : public RoverAction {
	
	public:
		virtual RoverAction* SpinLeft();
		virtual RoverAction* SpinRight();
		virtual Position TryToMove( const Position& );
		virtual const char* GetState();
	};

	class EastAction : public RoverAction {
	
	public:
		virtual RoverAction* SpinLeft();
		virtual RoverAction* SpinRight();
		virtual Position TryToMove( const Position& );
		virtual const char* GetState();
	};

	class SouthAction : public RoverAction {
	
	public:
		virtual RoverAction* SpinLeft();
		virtual RoverAction* SpinRight();
		virtual Position TryToMove( const Position& );
		virtual const char* GetState();
	};

	class WestAction : public RoverAction {
	
	public:
		virtual RoverAction* SpinLeft();
		virtual RoverAction* SpinRight();
		virtual Position TryToMove( const Position& );
		virtual const char* GetState();
	};

	template<class T>
	RoverAction* CreateActionSington(){

		static  T obj;
		return &obj;
	}

	class Command{
	
	public:
		virtual ~Command(){};
		virtual void Execute( Position&, RoverAction*&, const Plateau& ) = 0;
	};

	class SpinLeft : public Command {
	
	public:
		virtual void Execute( Position&, RoverAction*&, const Plateau& );
	};

	class SpinRight : public Command {
	
	public:
		virtual void Execute( Position&, RoverAction*&, const Plateau& );
	};

	class Move : public Command {
	
	public:
		virtual void Execute( Position&, RoverAction*&, const Plateau& );
	};

	template<class T>
	Command* CreateCommandSington(){
	
		static T obj;
		return & obj;
	}


	class Rover{
	
	public:
		Rover::Rover( const Plateau&,const Position&, RoverAction* );
		~Rover(){};

		bool AcceptCommand( Command& );
		bool GetState( string& );

	private:

		Rover& operator =( const Rover& );

		const Plateau& mrPlateau;

		Position mPos;		
		RoverAction* mpAction;
	};



}


#endif