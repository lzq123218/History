
#include <iostream>
#include <fstream>
#include <string>

#include "MarsRover.h"

using std::string;
using std::ifstream;
using std::cout;
using std::endl;

using namespace MarsRover;

void test(){
	
	Plateau lMars( 5, 5 );
	Position lpos( 5, 5 );

	RoverAction* init = CreateActionSington<SouthAction>();

	Rover first( lMars, lpos, init );

	Command* cmd = CreateCommandSington<Move>();

	first.AcceptCommand( *cmd );

	cmd = CreateCommandSington<SpinLeft>();

	first.AcceptCommand( *cmd );

	cmd = CreateCommandSington<SpinRight>();

	first.AcceptCommand( *cmd );
}


//Read the size of Plateau and validate it

bool GetPlateauSize( ifstream& aInput,int& aX, int& aY ){

	bool ret = false;

	aInput >> aX >> aY;

	if( aInput.good() && aX > 0 && aY > 0 ) ret = true;

	return ret;
}

//Read orignal position and direction,validate direction and create responding RoverAction

bool GetRoverOriginalPosition( ifstream& aInput,int& aX, int& aY, RoverAction*& apAction  ){

	bool ret = false;
	char direction = 0;

	apAction = NULL;

	aInput >> aX >> aY >> direction;

	if ( aInput.good() && aX >= 0 && aY >= 0 ){
	
		switch ( direction ){
		
		case 'N':
				apAction = CreateActionSington<NorthAction>();
				break;
		case 'E':
				apAction = CreateActionSington<EastAction>();
				break;
		case 'S':
				apAction = CreateActionSington<SouthAction>();
				break;
		case 'W':
				apAction = CreateActionSington<WestAction>();
				break;
		default:
			;
		}
	}

	if ( apAction ) ret = true;

	return ret;
}

//Read command sequence and check whether it is valid

bool GetCommandSequence( ifstream& aInput, string& aCommand ){

	bool ret = false;

	aInput.ignore( 1, '\n' );

	string cmd;

	getline( aInput, cmd );

	if ( aInput.good() ){
	
		int len = cmd.length();

		ret = true;

		for ( int i = 0; i < len; i++ ){
		
			char chr = cmd[i];

			switch ( chr ){
			
				case 'L':
				case 'R':
				case 'M':
						break;

				default:
						ret = false;
			}

			if ( !ret ) break;
		}
	}

	if ( ret ) aCommand = cmd;

	return ret;
}

//Send a sequece of command to Rover

bool ControlRover( Rover& aRover, string& aCmd ){

		bool ret = true;
		int len = aCmd.length();

		for ( int i = 0; i < len; i++ ){
		
			char chr = aCmd[i];

			Command* instruction = NULL;

			switch ( chr ){
			
				case 'L':
					instruction = CreateCommandSington<SpinLeft>();
					break;

				case 'R':
					instruction = CreateCommandSington<SpinRight>();
					break;

				case 'M':
					instruction = CreateCommandSington<Move>();
					break;

				default:
					;
			}

			if ( instruction ){

				aRover.AcceptCommand( *instruction );
			
			}else{
			
				ret = false; 
				break;
			}
	
		}

		return ret;
}

// return value means how many rovers landed on Mars successfully

unsigned int ExploreMars( const char* aScript ){

	bool res = false;
	unsigned int RoversCnt = 0;

	ifstream input( aScript );

	if ( input.fail() ) return RoversCnt;

	int x = -1, y = -1;

	if ( res = GetPlateauSize( input, x, y ) ){

		Plateau lMars( x, y );

		do {

			RoverAction* initAction = NULL;

			if ( res = GetRoverOriginalPosition( input, x, y, initAction ) ){

				Position lpos( x, y );

				if ( res = lMars.Contains( lpos ) ){

					Rover landingRover( lMars, lpos, initAction );

					string cmd;

					if ( res = GetCommandSequence( input, cmd ) ){
					
						res = ControlRover( landingRover, cmd );

						if ( res ) {
							
							RoversCnt++;

							string report;

							landingRover.GetState( report );

							cout << report << endl;
						}
					}
				}
			}

		}while ( res );

	}

	input.close();

	return RoversCnt;
}


int main(int argc, char* argv[]){

	char* testcases[] = {
	
		"testcase.txt",
		"testcase2.txt",
		"plateau_err.txt",
		"orignalPosition_err.txt",
		"direction_err.txt",
		"command_err.txt",
		NULL
	};

	unsigned int RoversCnt = 0;

	for ( char** filename = testcases; *filename; filename++ ){

		cout << *filename << endl;

		RoversCnt = ExploreMars( *filename );

		cout << "released " << RoversCnt << " rovers" << endl;

	}

	return 0;
}

